(() => {
	ScrollOut({
		cssProps: {
			viewportY: true,
			visibleY: true
		}
	});
})();